const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const sequelize = require('./config/db');

const productosRoutes = require('./routes/productos');
const ventasRoutes = require('./routes/ventas');
const usuariosRoutes = require('./routes/usuarios');
const reportesRoutes = require('./routes/reportes');
const rolesRoutes = require('./routes/roles');

const app = express();

// Middlewares
app.use(cors());
app.use(bodyParser.json());

// Rutas
app.use('/productos', productosRoutes);
app.use('/ventas', ventasRoutes);
app.use('/usuarios', usuariosRoutes);
app.use('/reportes', reportesRoutes);
app.use('/roles', rolesRoutes);

// Sincronizar modelos y arrancar el servidor
// Sincroniza todos los modelos con la base de datos
sequelize.sync()
    .then(() => {
        console.log('Conexión a la base de datos establecida');
    })
    .catch((err) => {
        console.error('Error al conectar a la base de datos:', err);
    });