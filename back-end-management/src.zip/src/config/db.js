const { Sequelize } = require('sequelize');

// Configuración de la conexión a la base de datos
const db = new Sequelize('db_management', 'root', 'admin', {
    host: 'localhost', // O el host de tu base de datos
    dialect: 'mysql',  // Tipo de base de datos que estás usando
    logging: false     // Desactivar los logs de SQL en consola
});

// Probar la conexión
db.authenticate()
    .then(() => console.log('Conexión a la base de datos establecida'))
    .catch(err => console.error('Error al conectar la base de datos:', err));

module.exports = db;
